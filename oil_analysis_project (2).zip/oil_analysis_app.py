import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from keywords import KEYWORDS_BG, KEYWORDS_EN
from datetime import datetime

# Езиков превключвател
language = st.sidebar.radio("🌐 Language / Език", ["Български", "English"])
is_bg = language == "Български"
KEYWORDS = KEYWORDS_BG if is_bg else KEYWORDS_EN

# Заглавие
st.title("🛢️ Нефтът и неговата роля в глобалния свят" if is_bg else "🛢️ Oil and Its Role in the Global World")

# Демонстрационни данни
def get_demo_data():
    dates = pd.date_range(start="2023-01-01", periods=180)
    prices = pd.Series(75 + 5 * np.sin(np.linspace(0, 10, 180)) + np.random.normal(0, 1, 180))
    return pd.DataFrame({"Date": dates, "Close": prices})

data = get_demo_data()

# Графика на петролните цени
st.subheader("📈 Исторически цени на петрола" if is_bg else "📈 Historical Oil Prices")
fig = px.line(data, x="Date", y="Close", title="Цени на суров петрол" if is_bg else "Crude Oil Price Trend")
st.plotly_chart(fig, use_container_width=True)

# Ключови думи и категории
st.sidebar.markdown("### 🗂️ " + ("Категории за анализ" if is_bg else "Categories for Analysis"))
selected_categories = st.sidebar.multiselect("Избери категории" if is_bg else "Choose categories", options=list(KEYWORDS.keys()), default=list(KEYWORDS.keys()))

st.subheader("🔍 Ключови думи по избрани категории" if is_bg else "🔍 Keywords from Selected Categories")
for category in selected_categories:
    st.markdown(f"**{category.title()}**: " + ", ".join(KEYWORDS[category]))

# Footer
st.markdown("---")
st.markdown(f"© {datetime.now().year} - Streamlit demo | Data is simulated for prototype.")


import yfinance as yf
import statsmodels.api as sm
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout

@st.cache_data
def fetch_oil_prices(ticker='CL=F', period='5y'):
    oil_data = yf.download(ticker, period=period, interval='1d')
    oil_data = oil_data[['Close']].dropna().reset_index()
    oil_data['Close'] = oil_data['Close'].astype(float)
    return oil_data

def arima_forecast(series, steps=30):
    model = sm.tsa.ARIMA(series, order=(5, 1, 0))
    model_fit = model.fit()
    forecast = model_fit.forecast(steps=steps)
    return forecast

def build_lstm_forecast_model(series, steps=30):
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(np.array(series).reshape(-1, 1))
    X_train, y_train = [], []
    for i in range(60, len(scaled) - steps):
        X_train.append(scaled[i-60:i])
        y_train.append(scaled[i])
    X_train, y_train = np.array(X_train), np.array(y_train)
    model = Sequential([
        LSTM(50, return_sequences=True, input_shape=(X_train.shape[1], 1)),
        Dropout(0.2),
        LSTM(50),
        Dropout(0.2),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')
    model.fit(X_train, y_train, epochs=3, batch_size=16, verbose=0)
    test_input = scaled[-60:].reshape(1, 60, 1)
    prediction = model.predict(test_input)
    return scaler.inverse_transform(prediction)[0][0]



import requests
from bs4 import BeautifulSoup
from textblob import TextBlob

@st.cache_data
def fetch_oil_news():
    urls = {
        "OilPrice.com": "https://oilprice.com/",
        "Neftoil.eu": "https://neftoil.eu/",
        "Fuelo.net": "https://bg.fuelo.net/prices/oil?lang=bg"
    }

    all_news = {}

    try:
        oilprice = requests.get(urls["OilPrice.com"], timeout=10)
        soup = BeautifulSoup(oilprice.text, 'html.parser')
        titles = [a.text.strip() for a in soup.find_all("a", class_="categoryArticle__title")[:5]]
        all_news["OilPrice.com"] = titles
    except Exception:
        all_news["OilPrice.com"] = []

    try:
        neftoil = requests.get(urls["Neftoil.eu"], timeout=10)
        soup = BeautifulSoup(neftoil.text, 'html.parser')
        titles = [a.text.strip() for a in soup.find_all("h2", class_="post-title")[:5]]
        all_news["Neftoil.eu"] = titles
    except Exception:
        all_news["Neftoil.eu"] = []

    try:
        fuelo = requests.get(urls["Fuelo.net"], timeout=10)
        soup = BeautifulSoup(fuelo.text, 'html.parser')
        table = soup.select("table tr")[1:]
        titles = [tr.get_text(separator=" | ", strip=True) for tr in table[:5]]
        all_news["Fuelo.net"] = titles
    except Exception:
        all_news["Fuelo.net"] = []

    return all_news

def analyze_sentiment(news_dict):
    total, count = 0, 0
    for source in news_dict:
        for title in news_dict[source]:
            sentiment = TextBlob(title).sentiment.polarity
            total += sentiment
            count += 1
    return total / count if count > 0 else 0

# Show section in app
st.subheader("📰 Новини и Пазарно настроение")
news_data = fetch_oil_news()
sentiment_score = analyze_sentiment(news_data)
st.markdown(f"**📊 Средна оценка на настроението:** `{sentiment_score:.2f}`")

for source, articles in news_data.items():
    with st.expander(f"📌 {source}"):
        for title in articles:
            st.markdown(f"- {title}")



import feedparser

@st.cache_data
def fetch_reliable_news():
    sources = {
        "Reuters Energy": "http://feeds.reuters.com/reuters/energyNews",
        "Bloomberg Energy": "https://www.bloomberg.com/feed/podcast/energy.xml",  # Some XML feeds may not parse well
        "CNN Energy": "http://rss.cnn.com/rss/money_news_international.rss",
        "Financial Times": "https://www.ft.com/?format=rss",
        "BBC Business": "http://feeds.bbci.co.uk/news/business/rss.xml"
    }

    news_results = {}
    for name, url in sources.items():
        try:
            parsed = feedparser.parse(url)
            entries = [entry.title for entry in parsed.entries[:5]]
            news_results[name] = entries
        except Exception as e:
            news_results[name] = [f"Грешка при зареждане: {e}"]
    return news_results

def analyze_sentiment(news_dict):
    total, count = 0, 0
    for source in news_dict:
        for title in news_dict[source]:
            sentiment = TextBlob(title).sentiment.polarity
            total += sentiment
            count += 1
    return total / count if count > 0 else 0

# Show improved news
st.subheader("🌐 Новини от международни източници")
reliable_news = fetch_reliable_news()
reliable_sentiment = analyze_sentiment(reliable_news)
st.markdown(f"**🌍 Среден индекс на настроенията:** `{reliable_sentiment:.2f}`")

for source, articles in reliable_news.items():
    with st.expander(f"📰 {source}"):
        for title in articles:
            st.markdown(f"- {title}")



from statsmodels.tsa.vector_ar.var_model import VAR
import matplotlib.pyplot as plt

def generate_synthetic_macro_data(oil_df):
    np.random.seed(42)
    gdp_growth = np.random.uniform(1, 4, size=len(oil_df))
    inflation = np.random.uniform(1, 8, size=len(oil_df))
    trade_balance = np.random.uniform(-5, 5, size=len(oil_df))
    df = pd.DataFrame({
        'Oil': oil_df['Close'].values,
        'GDP': gdp_growth,
        'Inflation': inflation,
        'TradeBalance': trade_balance
    }, index=oil_df['Date'])
    return df

st.subheader("📉 VAR анализ и Импулсни Реакции")

if 'oil_data' not in st.session_state:
    st.session_state.oil_data = fetch_oil_prices()

macro_data = generate_synthetic_macro_data(st.session_state.oil_data)

# Интерактивен избор на държави и сценарии
st.sidebar.markdown("### 🌍 Избор на държава / сценарий")
selected_country = st.sidebar.selectbox("Избери държава:", ["САЩ", "Китай", "Русия", "Саудитска Арабия", "ЕС", "Индия"])
shock_strength = st.sidebar.slider("Шок върху цената на петрола (%):", -50, 100, 10, step=5)

# Шокираните данни
macro_data_shocked = macro_data.copy()
macro_data_shocked['Oil'] *= (1 + shock_strength / 100)

model = VAR(macro_data_shocked)
results = model.fit(maxlags=4)

fig = results.irf(10).plot(orth=True)
st.pyplot(fig)

st.markdown(f"📌 Сценарий за `{selected_country}`: Шок от **{shock_strength}%** върху цената на петрола")
