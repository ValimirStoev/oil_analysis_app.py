# Multilingual keyword dictionaries for analysis, tagging, and search

KEYWORDS_BG = {
    'петрол': ['брент', 'wti', 'нефт', 'суров петрол', 'цена на петрола', 'добив', 'търсене', 'предлагане', 'варел', 'оПЕК', 'оПЕК+', 'енергийна криза', 'запаси от петрол', 'санкции върху петрол'],
    'икономика': ['бвп', 'инфлация', 'лихвен процент', 'рецесия', 'фискална политика', 'парична политика', 'търговски баланс', 'централни банки', 'глобализация', 'вериги на доставки'],
    'фондов пазар': ['фондов пазар', 'борсов индекс', 'волатилност', 'мечи пазар', 'бичи пазар', 'инвеститори', 'рискове', 'пазарна капитализация', 'хедж фондове'],
    'геополитика': ['санкции', 'война', 'конфликт', 'близък изток', 'геополитическо напрежение', 'енергийна зависимост'],
    'събития': ['оПЕК+ среща', 'ембарго', 'пандемия', 'криза', 'интервенция', 'енергийна война'],
    'държави': ['Русия', 'САЩ', 'Китай', 'Саудитска Арабия', 'Иран', 'Ирак', 'ОАЕ', 'Венецуела', 'Канада', 'Бразилия', 'Норвегия', 'Катар', 'Нигерия', 'Алжир', 'Либия', 'Кувейт', 'Казахстан', 'Индия', 'Германия', 'Франция', 'Великобритания', 'ЕС', 'Африка', 'Азия', 'Европа', 'Близък изток']
}

KEYWORDS_EN = {
    'oil': ['brent', 'wti', 'oil', 'crude oil', 'oil price', 'barrel', 'supply', 'demand', 'production', 'opec', 'opec+', 'energy crisis', 'oil reserves', 'oil sanctions'],
    'economy': ['gdp', 'inflation', 'interest rate', 'recession', 'fiscal policy', 'monetary policy', 'trade balance', 'central banks', 'globalization', 'supply chains'],
    'stock market': ['stock market', 'stock index', 'volatility', 'bear market', 'bull market', 'investors', 'uncertainty', 'market capitalization', 'hedge funds'],
    'geopolitics': ['sanctions', 'war', 'conflict', 'middle east', 'geopolitical tension', 'energy dependency'],
    'events': ['opec+ meeting', 'embargo', 'pandemic', 'crisis', 'intervention', 'energy war'],
    'countries': ['Russia', 'USA', 'China', 'Saudi Arabia', 'Iran', 'Iraq', 'UAE', 'Venezuela', 'Canada', 'Brazil', 'Norway', 'Qatar', 'Nigeria', 'Algeria', 'Libya', 'Kuwait', 'Kazakhstan', 'India', 'Germany', 'France', 'UK', 'EU', 'Africa', 'Asia', 'Europe', 'Middle East']
}